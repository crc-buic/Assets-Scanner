# pip install python-nmap
import nmap



def detect(target):
    try:
        print(target)
        nm = nmap.PortScanner()
        machine = nm.scan(target, arguments='-v -sSU -pT:20-25,80,443-445,U:54321-54330 -O')
        print(machine['scan'][target]['osmatch'][0]['osclass'][0]['osfamily'])
        return 1
    except Exception as e:
        return 0

ips = ['172.16.221.112','172.16.221.128','172.16.221.1','172.16.221.215']

    
for i in range(len(ips)):
    detect(ips[i])




# nmap -v -sSU -pT:20-25,80,443-445,U:54321-54330 -O 172.16.221.1

