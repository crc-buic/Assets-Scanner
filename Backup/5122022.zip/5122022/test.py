import os
# pip install python-nmap
import nmap
import json



# # Zmap Scanning
# scan_command =  'zmap --cooldown-time=3 --bandwidth=5000K --probe-module=icmp_echoscan 172.16.221.0/24 -o list.txt' 
# #print(scan_command)
# os.system(scan_command)
f = open("list.txt", "r")
ip_list =  f.read().split('\n')
while("" in ip_list) :
    ip_list.remove("")

print(f'{len(ip_list)} hosts detected.\nDetecting OS .... \n')

for ip in ip_list:
    nm = nmap.PortScanner()
    machine = nm.scan(ip, arguments='-O')
    detected_os = machine['scan'][ip]['osmatch'][0]['osclass'][0]['osfamily']
    print(f'IP: {ip} | OS: {detected_os}')


# making json formatted variable to store ip along with OS
ip_os_details = {"IP": ip, "OS": detected_os}


# writing data to json file
with open("assets.json", "a") as write_file:
json.dump(ip_os_details, write_file)